# XC Planner — Production (Deploy)
Upload the contents of this folder to Netlify Drop or GitHub Pages. You will get a permanent HTTPS URL that works on desktop and mobile. Add your domain via CNAME if desired.
